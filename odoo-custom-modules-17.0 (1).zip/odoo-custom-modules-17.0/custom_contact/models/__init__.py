# -*- coding: utf-8 -*-

from . import res_partner
from . import res_user
from . import settings