# -*- coding: utf-8 -*-

from . import medical_appointment
