# -*- coding: utf-8 -*-

from . import settings
from . import customer
from . import res_partner